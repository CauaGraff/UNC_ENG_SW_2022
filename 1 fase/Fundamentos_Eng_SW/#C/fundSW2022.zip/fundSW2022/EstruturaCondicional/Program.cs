﻿using System;


namespace EstruturaCondicional
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var a = 3;
            var b = 2;
            if (3>2)
            {
                Console.WriteLine("é maior");
            }
            Console.WriteLine("Encerado");


        }
    }
}
